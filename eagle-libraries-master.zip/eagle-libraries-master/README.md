eagle-libraries
===============

Footprints and parts for Open Ephys designs
